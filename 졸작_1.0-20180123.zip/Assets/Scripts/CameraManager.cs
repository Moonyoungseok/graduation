﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour {

    public float speed = 5f;

    public Transform plane;

    private Vector3 rot = new Vector3();

    private float distance = 2f;
    private Vector3 zoomVec;
    public int cnt = 0;

    public float cly = 0f;
    public float clx = 0f;
    private void Start()
    {

        
    }
   
    public void Update()
    {
        if(Input.GetMouseButton(1))
        {


          
                rot.x = -Input.GetAxis("Mouse Y") * speed;
                rot.y = Input.GetAxis("Mouse X") * speed;
               

           // rot.x = Mathf.Clamp(rot.x, -1000f, 1000f);

        transform.rotation *= Quaternion.Euler(rot);

        transform.position = plane.position + new Vector3(0f, 0.7f, 0f);

        distance += -Input.GetAxis("Mouse ScrollWheel") * speed;
        distance = Mathf.Clamp(distance, 10f, 10f);

        zoomVec = transform.forward * -1;
        zoomVec *= distance;
        Camera.main.transform.position = transform.position + zoomVec;

        Vector3 rayDirection = (transform.up * 0.1f) + (transform.forward * -2);
        RaycastHit hitPoint;

        Physics.Raycast(transform.position, rayDirection, out hitPoint, distance);

        if (hitPoint.point != Vector3.zero)
        {
            Camera.main.transform.position = hitPoint.point;

            Camera.main.transform.Translate(new Vector3(0f, 0.1f));
        }

        }
       

    }

    
}
