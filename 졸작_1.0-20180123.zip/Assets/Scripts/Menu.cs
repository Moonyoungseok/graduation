﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menu : MonoBehaviour {

    public GameObject obj;
    public void NewObject()
    {
        Instantiate(obj, new Vector3(0, 0, 0), Quaternion.identity);
    }
}
