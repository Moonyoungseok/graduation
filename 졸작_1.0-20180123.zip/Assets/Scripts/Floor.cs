﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floor : MonoBehaviour {

    float speed = 20f;

    float rotSpeed = 5f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetMouseButton(1))
        {
            float h = Input.GetAxis("Horizontal");
            float v = Input.GetAxis("Vertical");

            h *= speed * Time.deltaTime;
            v *= speed * Time.deltaTime;

            transform.Translate(Vector3.right * h);
            transform.Translate(Vector3.forward * v);

            float MouseX = Input.GetAxis("Mouse X");
            float MouseY = Input.GetAxis("Mouse Y");


            transform.Rotate(Vector3.down * rotSpeed * MouseX);
            transform.Rotate(Vector3.right * rotSpeed * MouseY);
        }
    }
}
