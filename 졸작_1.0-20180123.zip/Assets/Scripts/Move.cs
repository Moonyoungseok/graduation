﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{


    public float speed = 2.5f;
    // 오브젝트의 충돌체

    private Collider _collide;

    // 현재 좌표

    private Vector3 _curPosition;

    // 목표 좌표

    private Vector3 _direction;

    // 마우스와 오브젝트가 충돌했는지 체크

    private bool _isTrigger = false;

    void Start()
    {
        _collide = GetComponent<Collider>();

    }

    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            this.transform.Translate(speed * Time.deltaTime, 0, 0);
        }

        if (Input.GetKey(KeyCode.UpArrow))
        {
            this.transform.Translate(0, 0, speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.DownArrow))
        {
            this.transform.Translate(0, 0, -speed * Time.deltaTime);
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            this.transform.Translate(-speed * Time.deltaTime, 0, 0);
        }

   
        }

     IEnumerator OnMouseDown()
      {
          Vector3 scrSpace = Camera.main.WorldToScreenPoint(transform.position);
          Vector3 offset = transform.position - Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, scrSpace.z));

          while (Input.GetMouseButton(0))
          {
            _isTrigger = true;
            Vector3 curScreenSpace = new Vector3(Input.mousePosition.x, Input.mousePosition.y, scrSpace.z);
              Vector3 curPosition = Camera.main.ScreenToWorldPoint(curScreenSpace) + offset;
            if (_isTrigger)
            {
                float step = 10* Time.deltaTime;
                transform.position = Vector3.MoveTowards(transform.position, curPosition,step);
            }
              yield return null;
          }
  
        if (transform.position == _curPosition)

        {

            _isTrigger = false;

        }

      }
   
}

